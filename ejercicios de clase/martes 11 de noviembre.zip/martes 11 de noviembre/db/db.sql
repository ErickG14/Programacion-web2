create database node_crud;
use  node_crud;

create table users (
    id INT PRIMARY KEY AUTO_INCREMENT, 
    name VARCHAR(100) ,
    email VARCHAR(100) 
);