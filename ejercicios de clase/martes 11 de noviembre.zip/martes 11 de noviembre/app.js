const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));

// Motor de plantillas
app.set('view engine', 'ejs');

// Conexión a MySQL
const db = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'YAZMIN1980',
  database: 'node_crud',
  port: 3306
});

db.connect((err) => {
  if (err) {
    console.error('Error en servidor:', err);
  } else {
    console.log('Conectado a la base de datos');
  }
});

// Servidor
const port = 3008;
app.listen(port, () => {
  console.log(`server http://localhost:${port}`);
});

// Ruta principal
app.get('/', (req, res) => {
  const sql = 'SELECT * FROM users';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al recuperar datos:', err);
      res.send('Error, no se recuperaron datos');
    } else {
      res.render('index', { users: results });
    }
  });
});
